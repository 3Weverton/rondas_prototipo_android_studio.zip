# Ronda Noturna — versão 2

Protótipo Flutter offline para testes.

## Regras
- Turno padrão: 21:00 até 07:00.
- 11 rondas: 21, 22, 23, 00, 01, 02, 03, 04, 05, 06 e 07.
- O botão de registrar só fica ativo durante a janela de uma hora da ronda.
- Ao registrar, salva a data e hora exatas do celular.
- Não há botão para editar/apagar uma marcação individual.
- Se passar uma hora sem registro, a ronda aparece como "Perdida / sem registro".
- Dados ficam no aparelho e funcionam sem internet.
- Histórico mostra as rondas do turno.

## Compilação
`flutter pub get`
`flutter build apk --release`
