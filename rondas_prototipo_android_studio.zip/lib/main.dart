import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

const List<int> roundHours = [21, 22, 23, 0, 1, 2, 3, 4, 5, 6, 7];

class RoundRecord {
  final String key;
  final String label;
  final String scheduledIso;
  final String? registeredIso;

  RoundRecord({
    required this.key,
    required this.label,
    required this.scheduledIso,
    this.registeredIso,
  });

  bool get completed => registeredIso != null;

  Map<String, dynamic> toJson() => {
    'key': key,
    'label': label,
    'scheduledIso': scheduledIso,
    'registeredIso': registeredIso,
  };

  factory RoundRecord.fromJson(Map<String, dynamic> j) => RoundRecord(
    key: j['key'],
    label: j['label'],
    scheduledIso: j['scheduledIso'],
    registeredIso: j['registeredIso'],
  );

  RoundRecord copyWith({String? registeredIso}) => RoundRecord(
    key: key,
    label: label,
    scheduledIso: scheduledIso,
    registeredIso: registeredIso ?? this.registeredIso,
  );
}

void main() => runApp(const RondaApp());

class RondaApp extends StatelessWidget {
  const RondaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Ronda Noturna',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.indigo,
        scaffoldBackgroundColor: const Color(0xFFF5F7FB),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with WidgetsBindingObserver {
  List<RoundRecord> rounds = [];
  bool loading = true;
  DateTime? shiftStart;
  String? message;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _load();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _load();
  }

  DateTime _dateOnly(DateTime d) => DateTime(d.year, d.month, d.day);

  DateTime _shiftStartFor(DateTime now) {
    final today = _dateOnly(now);
    if (now.hour >= 21) return today.add(const Duration(hours: 21));
    if (now.hour < 8) return today.subtract(const Duration(days: 1)).add(const Duration(hours: 21));
    return today.add(const Duration(hours: 21));
  }

  List<RoundRecord> _makeRounds(DateTime start) {
    return List.generate(roundHours.length, (i) {
      final dt = start.add(Duration(hours: i));
      final key = '${dt.year}-${dt.month}-${dt.day}-${dt.hour}';
      return RoundRecord(
        key: key,
        label: _hourLabel(dt.hour),
        scheduledIso: dt.toIso8601String(),
      );
    });
  }

  String _hourLabel(int hour) => '${hour.toString().padLeft(2, '0')}:00';

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final now = DateTime.now();
    final start = _shiftStartFor(now);
    final base = _makeRounds(start);
    final raw = prefs.getString('rounds_${start.toIso8601String()}');

    List<RoundRecord> saved = [];
    if (raw != null) {
      try {
        saved = (jsonDecode(raw) as List)
            .map((e) => RoundRecord.fromJson(Map<String, dynamic>.from(e)))
            .toList();
      } catch (_) {}
    }

    final byKey = {for (final r in saved) r.key: r};
    rounds = base.map((r) => byKey[r.key] ?? r).toList();
    shiftStart = start;
    loading = false;
    if (mounted) setState(() {});
  }

  Future<void> _save() async {
    if (shiftStart == null) return;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      'rounds_${shiftStart!.toIso8601String()}',
      jsonEncode(rounds.map((r) => r.toJson()).toList()),
    );
  }

  DateTime get now => DateTime.now();

  String _status(RoundRecord r) {
    if (r.completed) return 'Concluída';
    final scheduled = DateTime.parse(r.scheduledIso);
    final next = scheduled.add(const Duration(hours: 1));
    final current = now;
    if (current.isBefore(scheduled)) return 'Em espera';
    if (current.isBefore(next)) return 'Em aberto';
    return 'Perdida / sem registro';
  }

  Color _statusColor(String status) {
    switch (status) {
      case 'Concluída':
        return Colors.green;
      case 'Em aberto':
        return Colors.orange;
      case 'Perdida / sem registro':
        return Colors.red;
      default:
        return Colors.blueGrey;
    }
  }

  RoundRecord? get currentRound {
    for (final r in rounds) {
      final s = _status(r);
      if (s == 'Em aberto') return r;
    }
    for (final r in rounds) {
      if (!r.completed && _status(r) == 'Em espera') return r;
    }
    return null;
  }

  Future<void> _register(RoundRecord r) async {
    if (_status(r) != 'Em aberto') {
      setState(() => message = 'Esta ronda não está no período de registro.');
      return;
    }
    final stamp = DateTime.now().toIso8601String();
    final index = rounds.indexWhere((x) => x.key == r.key);
    if (index < 0 || rounds[index].completed) return;

    setState(() {
      rounds[index] = rounds[index].copyWith(registeredIso: stamp);
      message = 'Ronda ${r.label} registrada às ${_formatTime(DateTime.parse(stamp))}.';
    });
    await _save();
  }

  String _formatTime(DateTime d) =>
      '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}:${d.second.toString().padLeft(2, '0')}';

  String _formatDate(DateTime d) =>
      '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}';

  String _shiftLabel() {
    if (shiftStart == null) return '';
    final end = shiftStart!.add(const Duration(hours: 10));
    return '${_formatDate(shiftStart!)} 21:00 → ${_formatDate(end)} 07:00';
  }

  Future<void> _newTest() async {
    final prefs = await SharedPreferences.getInstance();
    if (shiftStart != null) {
      await prefs.remove('rounds_${shiftStart!.toIso8601String()}');
    }
    await _load();
    setState(() => message = 'Novo turno de teste preparado.');
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    final current = currentRound;
    final completed = rounds.where((r) => r.completed).length;
    final lost = rounds.where((r) => _status(r) == 'Perdida / sem registro').length;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Ronda Noturna'),
        actions: [
          IconButton(
            tooltip: 'Histórico',
            icon: const Icon(Icons.history),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => HistoryPage(rounds: rounds)),
            ),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Turno', style: Theme.of(context).textTheme.titleMedium),
                    const SizedBox(height: 4),
                    Text(_shiftLabel(), style: Theme.of(context).textTheme.titleLarge),
                    const SizedBox(height: 14),
                    Row(
                      children: [
                        _Counter(label: 'Concluídas', value: '$completed', color: Colors.green),
                        const SizedBox(width: 8),
                        _Counter(label: 'Perdidas', value: '$lost', color: Colors.red),
                        const SizedBox(width: 8),
                        _Counter(label: 'Total', value: '${rounds.length}', color: Colors.indigo),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            if (current != null)
              Card(
                elevation: 2,
                child: Padding(
                  padding: const EdgeInsets.all(18),
                  child: Column(
                    children: [
                      const Text('PRÓXIMA RONDA / RONDA ATUAL',
                          style: TextStyle(fontWeight: FontWeight.bold)),
                      const SizedBox(height: 6),
                      Text(current.label,
                          style: const TextStyle(fontSize: 36, fontWeight: FontWeight.w700)),
                      const SizedBox(height: 10),
                      Text(
                        _status(current),
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: _statusColor(_status(current)),
                        ),
                      ),
                      const SizedBox(height: 14),
                      SizedBox(
                        width: double.infinity,
                        child: FilledButton.icon(
                          onPressed: _status(current) == 'Em aberto'
                              ? () => _register(current)
                              : null,
                          icon: const Icon(Icons.check_circle),
                          label: const Text('REGISTRAR RONDA'),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            if (message != null) ...[
              const SizedBox(height: 8),
              Card(
                color: Colors.indigo.withOpacity(.08),
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Text(message!),
                ),
              ),
            ],
            const SizedBox(height: 12),
            Text('Rondas do turno',
                style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 6),
            ...rounds.map((r) {
              final status = _status(r);
              final color = _statusColor(status);
              return Card(
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundColor: color.withOpacity(.12),
                    child: Icon(
                      status == 'Concluída'
                          ? Icons.check
                          : status == 'Perdida / sem registro'
                              ? Icons.close
                              : status == 'Em aberto'
                                  ? Icons.radio_button_checked
                                  : Icons.schedule,
                      color: color,
                    ),
                  ),
                  title: Text('Ronda ${r.label}',
                      style: const TextStyle(fontWeight: FontWeight.w600)),
                  subtitle: Text(
                    r.completed
                        ? 'Registrada às ${_formatTime(DateTime.parse(r.registeredIso!))}'
                        : status,
                  ),
                  trailing: Text(status,
                      style: TextStyle(color: color, fontWeight: FontWeight.bold)),
                ),
              );
            }),
            const SizedBox(height: 10),
            OutlinedButton.icon(
              onPressed: _newTest,
              icon: const Icon(Icons.restart_alt),
              label: const Text('Preparar novo turno de teste'),
            ),
            const SizedBox(height: 30),
            const Text(
              'Os horários registrados são gravados automaticamente e não existe opção de editar ou apagar uma marcação individual.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.black54),
            ),
          ],
        ),
      ),
    );
  }
}

class _Counter extends StatelessWidget {
  final String label;
  final String value;
  final Color color;
  const _Counter({required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
        decoration: BoxDecoration(
          color: color.withOpacity(.08),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          children: [
            Text(value, style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: color)),
            Text(label, style: const TextStyle(fontSize: 11)),
          ],
        ),
      ),
    );
  }
}

class HistoryPage extends StatelessWidget {
  final List<RoundRecord> rounds;
  const HistoryPage({super.key, required this.rounds});

  String fmt(DateTime d) =>
      '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')} '
      '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}:${d.second.toString().padLeft(2, '0')}';

  @override
  Widget build(BuildContext context) {
    final done = rounds.where((r) => r.completed).toList();
    return Scaffold(
      appBar: AppBar(title: const Text('Histórico do turno')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Text(
                'Registros feitos: ${done.length} de ${rounds.length}',
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ),
          ),
          const SizedBox(height: 8),
          ...rounds.map((r) {
            final status = r.completed
                ? 'Concluída'
                : DateTime.now().isAfter(DateTime.parse(r.scheduledIso).add(const Duration(hours: 1)))
                    ? 'Perdida / sem registro'
                    : 'Sem registro ainda';
            return ListTile(
              leading: Icon(r.completed ? Icons.check_circle : Icons.info_outline,
                  color: r.completed ? Colors.green : Colors.red),
              title: Text('Ronda ${r.label} — $status'),
              subtitle: Text(r.completed
                  ? 'Registro imutável: ${fmt(DateTime.parse(r.registeredIso!))}'
                  : 'Nenhum horário registrado para esta ronda.'),
            );
          }),
        ],
      ),
    );
  }
}
