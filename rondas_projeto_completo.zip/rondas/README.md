# Minhas Rondas

Aplicativo Flutter offline para registrar rondas.

## Recursos
- Registro somente a partir do horário previsto e dentro de uma janela de 30 minutos.
- Rondas perdidas são marcadas automaticamente.
- Histórico persistente no aparelho, incluindo turnos que atravessam a meia-noite.
- Histórico de dias anteriores.
- Registro opcional com foto da câmera ou galeria.
- Fotos copiadas para armazenamento permanente do aplicativo e vinculadas à ronda.
- Compartilhamento do histórico em texto.
- Configuração do horário inicial e final do turno.

## Compilação no GitHub Actions
O workflow incluído gera o APK. Na primeira execução ele cria a pasta Android se ela ainda não existir. Depois disso, a pasta Android existente é preservada.
