import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const RondasApp());

class Ronda {
  final String previsto;
  final String previstoIso;
  final String? registrado;
  final String status; // em_espera, concluida, perdida
  final String? foto;

  Ronda({
    required this.previsto,
    required this.previstoIso,
    this.registrado,
    required this.status,
    this.foto,
  });

  Ronda copyWith({String? registrado, String? status, String? foto}) => Ronda(
        previsto: previsto,
        previstoIso: previstoIso,
        registrado: registrado ?? this.registrado,
        status: status ?? this.status,
        foto: foto ?? this.foto,
      );

  Map<String, dynamic> toJson() => {
        'previsto': previsto,
        'previstoIso': previstoIso,
        'registrado': registrado,
        'status': status,
        'foto': foto,
      };

  factory Ronda.fromJson(Map<String, dynamic> j) => Ronda(
        previsto: j['previsto'] as String,
        previstoIso: (j['previstoIso'] as String?) ?? '',
        registrado: j['registrado'] as String?,
        status: j['status'] as String? ?? 'em_espera',
        foto: j['foto'] as String?,
      );
}

class Turno {
  final String dataInicio;
  final List<Ronda> rondas;

  Turno({required this.dataInicio, required this.rondas});

  Map<String, dynamic> toJson() => {
        'dataInicio': dataInicio,
        'rondas': rondas.map((e) => e.toJson()).toList(),
      };

  factory Turno.fromJson(Map<String, dynamic> j) => Turno(
        dataInicio: j['dataInicio'] as String,
        rondas: (j['rondas'] as List)
            .map((e) => Ronda.fromJson(Map<String, dynamic>.from(e)))
            .toList(),
      );
}

class RondasApp extends StatelessWidget {
  const RondasApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Minhas Rondas',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),
        useMaterial3: true,
      ),
      home: const RondasPage(),
    );
  }
}

class RondasPage extends StatefulWidget {
  const RondasPage({super.key});

  @override
  State<RondasPage> createState() => _RondasPageState();
}

class _RondasPageState extends State<RondasPage> {
  final ImagePicker _picker = ImagePicker();
  final List<Turno> _turnos = [];
  int _inicio = 22;
  int _fim = 7;
  bool _carregando = true;
  bool _processando = false;

  @override
  void initState() {
    super.initState();
    _carregar();
  }

  Future<void> _carregar() async {
    final p = await SharedPreferences.getInstance();
    _inicio = p.getInt('inicio') ?? 22;
    _fim = p.getInt('fim') ?? 7;
    final raw = p.getString('turnos');
    if (raw != null) {
      try {
        _turnos
          ..clear()
          ..addAll((jsonDecode(raw) as List).map(
              (e) => Turno.fromJson(Map<String, dynamic>.from(e))));
      } catch (_) {
        _turnos.clear();
      }
    }
    _garantirTurnoAtual();
    _atualizarPerdidas();
    await _salvar();
    if (mounted) setState(() => _carregando = false);
  }

  Future<void> _salvar() async {
    final p = await SharedPreferences.getInstance();
    await p.setInt('inicio', _inicio);
    await p.setInt('fim', _fim);
    await p.setString('turnos', jsonEncode(_turnos.map((e) => e.toJson()).toList()));
  }

  DateTime _inicioDoTurno(DateTime agora) {
    final hoje = DateTime(agora.year, agora.month, agora.day, _inicio);
    final atravessaMeiaNoite = _inicio > _fim;
    if (atravessaMeiaNoite && agora.hour < _inicio) {
      return hoje.subtract(const Duration(days: 1));
    }
    if (!atravessaMeiaNoite && agora.isBefore(hoje)) {
      return hoje.subtract(const Duration(days: 1));
    }
    return hoje;
  }

  Turno _criarTurno(DateTime inicioTurno) {
    final inicio = DateTime(inicioTurno.year, inicioTurno.month, inicioTurno.day, _inicio);
    int total = (_fim - _inicio + 24) % 24;
    if (total == 0) total = 24;
    final rondas = <Ronda>[];
    for (int i = 0; i <= total; i++) {
      final previsto = inicio.add(Duration(hours: i));
      rondas.add(Ronda(
        previsto: '${previsto.hour.toString().padLeft(2, '0')}:00',
        previstoIso: previsto.toIso8601String(),
        status: 'em_espera',
      ));
    }
    return Turno(dataInicio: _dataChave(inicio), rondas: rondas);
  }

  String _dataChave(DateTime d) =>
      '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  void _garantirTurnoAtual() {
    final chave = _dataChave(_inicioDoTurno(DateTime.now()));
    if (!_turnos.any((t) => t.dataInicio == chave)) {
      _turnos.insert(0, _criarTurno(_inicioDoTurno(DateTime.now())));
    }
    _turnos.sort((a, b) => b.dataInicio.compareTo(a.dataInicio));
  }

  DateTime _previstoDate(Ronda r) {
    if (r.previstoIso.isNotEmpty) return DateTime.parse(r.previstoIso);
    final p = r.previsto.split(':');
    final agora = DateTime.now();
    return DateTime(agora.year, agora.month, agora.day, int.parse(p[0]));
  }

  void _atualizarPerdidas() {
    final agora = DateTime.now();
    bool mudou = false;
    for (final turno in _turnos) {
      for (int i = 0; i < turno.rondas.length; i++) {
        final r = turno.rondas[i];
        if (r.status != 'em_espera') continue;
        final previsto = _previstoDate(r);
        if (agora.isAfter(previsto.add(const Duration(minutes: 30)))) {
          turno.rondas[i] = r.copyWith(status: 'perdida');
          mudou = true;
        }
      }
    }
    if (mudou) _salvar();
  }

  Turno get _turnoAtual {
    final chave = _dataChave(_inicioDoTurno(DateTime.now()));
    return _turnos.firstWhere((t) => t.dataInicio == chave,
        orElse: () => _criarTurno(_inicioDoTurno(DateTime.now())));
  }

  int get _proximaIndex {
    final agora = DateTime.now();
    final rondas = _turnoAtual.rondas;
    for (int i = 0; i < rondas.length; i++) {
      final r = rondas[i];
      if (r.status != 'em_espera') continue;
      final previsto = _previstoDate(r);
      final fimJanela = previsto.add(const Duration(minutes: 30));
      if (!agora.isBefore(previsto) && !agora.isAfter(fimJanela)) return i;
      if (agora.isAfter(fimJanela)) continue;
      // Como as rondas são ordenadas, uma futura significa que nenhuma posterior
      // pode ser registrada ainda.
      break;
    }
    return -1;
  }

  Future<String?> _salvarFoto(XFile arquivo) async {
    final dir = await getApplicationDocumentsDirectory();
    final fotos = Directory('${dir.path}/fotos_rondas');
    if (!await fotos.exists()) await fotos.create(recursive: true);
    final nome = 'ronda_${DateTime.now().millisecondsSinceEpoch}.jpg';
    final destino = File('${fotos.path}/$nome');
    await File(arquivo.path).copy(destino.path);
    return destino.path;
  }

  Future<void> _registrar() async {
    if (_processando) return;
    _atualizarPerdidas();
    final idx = _proximaIndex;
    if (idx < 0) {
      final agora = DateTime.now();
      final primeira = _turnoAtual.rondas.firstWhere(
        (r) => r.status == 'em_espera',
        orElse: () => Ronda(previsto: '', previstoIso: '', status: 'perdida'),
      );
      if (primeira.previstoIso.isNotEmpty && agora.isBefore(_previstoDate(primeira))) {
        _mostrar('Ainda não chegou o horário da próxima ronda.');
      } else {
        _mostrar('Não há ronda dentro da janela de 30 minutos para registrar agora.');
      }
      return;
    }

    setState(() => _processando = true);
    try {
      final escolha = await showModalBottomSheet<String>(
        context: context,
        builder: (context) => SafeArea(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            ListTile(
              leading: const Icon(Icons.photo_camera),
              title: const Text('Registrar com foto'),
              onTap: () => Navigator.pop(context, 'camera'),
            ),
            ListTile(
              leading: const Icon(Icons.photo_library),
              title: const Text('Escolher foto da galeria'),
              onTap: () => Navigator.pop(context, 'galeria'),
            ),
            ListTile(
              leading: const Icon(Icons.check_circle_outline),
              title: const Text('Registrar sem foto'),
              onTap: () => Navigator.pop(context, 'sem_foto'),
            ),
          ]),
        ),
      );

      if (!mounted || escolha == null) return;
      String? foto;
      if (escolha == 'camera') {
        final arquivo = await _picker.pickImage(source: ImageSource.camera, imageQuality: 80);
        if (arquivo != null) foto = await _salvarFoto(arquivo);
      } else if (escolha == 'galeria') {
        final arquivo = await _picker.pickImage(source: ImageSource.gallery, imageQuality: 80);
        if (arquivo != null) foto = await _salvarFoto(arquivo);
      }
      if (escolha != 'sem_foto' && foto == null) return;

      final agora = DateTime.now();
      final hora = '${agora.hour.toString().padLeft(2, '0')}:${agora.minute.toString().padLeft(2, '0')}:${agora.second.toString().padLeft(2, '0')}';
      final turno = _turnoAtual;
      final r = turno.rondas[idx];
      turno.rondas[idx] = r.copyWith(registrado: hora, status: 'concluida', foto: foto);
      await _salvar();
      if (mounted) setState(() {});
      _mostrar(foto == null ? 'Ronda registrada.' : 'Ronda registrada com foto.');
    } finally {
      if (mounted) setState(() => _processando = false);
    }
  }

  void _mostrar(String texto) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(texto)));
  }

  String _formatarData(String chave) {
    final p = chave.split('-');
    if (p.length != 3) return chave;
    return '${p[2]}/${p[1]}/${p[0]}';
  }

  String _statusTexto(String s) {
    switch (s) {
      case 'concluida': return 'Ronda concluída';
      case 'perdida': return 'Ronda perdida — sem registro';
      default: return 'Em espera';
    }
  }

  Color _statusCor(String s) {
    switch (s) {
      case 'concluida': return Colors.green;
      case 'perdida': return Colors.red;
      default: return Colors.orange;
    }
  }

  Future<void> _abrirFoto(String caminho) async {
    final arquivo = File(caminho);
    if (!await arquivo.exists()) {
      _mostrar('A foto não está mais disponível.');
      return;
    }
    if (!mounted) return;
    showDialog(
      context: context,
      builder: (_) => Dialog(
        child: InteractiveViewer(child: Image.file(arquivo, fit: BoxFit.contain)),
      ),
    );
  }

  String _textoHistorico() {
    final b = StringBuffer('HISTÓRICO DE RONDAS\n\n');
    for (final turno in _turnos) {
      b.writeln('Turno iniciado em ${_formatarData(turno.dataInicio)}');
      for (final r in turno.rondas) {
        final extra = r.registrado == null ? '' : ' — registrada às ${r.registrado}';
        b.writeln('${r.previsto} — ${_statusTexto(r.status)}$extra${r.foto != null ? ' — com foto' : ''}');
      }
      b.writeln();
    }
    return b.toString();
  }

  Future<void> _compartilhar() async {
    await Share.share(_textoHistorico(), subject: 'Histórico de rondas');
  }

  Future<void> _configurar() async {
    int inicio = _inicio;
    int fim = _fim;
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (context, setLocal) => AlertDialog(
          title: const Text('Horário das rondas'),
          content: Row(children: [
            Expanded(
              child: DropdownButtonFormField<int>(
                value: inicio,
                decoration: const InputDecoration(labelText: 'Início'),
                items: List.generate(24, (h) => DropdownMenuItem(value: h, child: Text('${h.toString().padLeft(2, '0')}h'))),
                onChanged: (v) => setLocal(() => inicio = v!),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: DropdownButtonFormField<int>(
                value: fim,
                decoration: const InputDecoration(labelText: 'Fim'),
                items: List.generate(24, (h) => DropdownMenuItem(value: h, child: Text('${h.toString().padLeft(2, '0')}h'))),
                onChanged: (v) => setLocal(() => fim = v!),
              ),
            ),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Aplicar')),
          ],
        ),
      ),
    );
    if (ok == true) {
      setState(() {
        _inicio = inicio;
        _fim = fim;
        _turnos.clear();
        _garantirTurnoAtual();
      });
      await _salvar();
    }
  }

  Widget _rondaTile(Ronda r) {
    return Card(
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: _statusCor(r.status),
          child: Icon(r.status == 'concluida' ? Icons.check : r.status == 'perdida' ? Icons.close : Icons.schedule, color: Colors.white),
        ),
        title: Text('Prevista: ${r.previsto}'),
        subtitle: Text('${_statusTexto(r.status)}${r.registrado != null ? ' • registrada às ${r.registrado}' : ''}'),
        trailing: r.foto != null ? IconButton(icon: const Icon(Icons.photo), tooltip: 'Ver foto', onPressed: () => _abrirFoto(r.foto!)) : null,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_carregando) return const Scaffold(body: Center(child: CircularProgressIndicator()));

    _garantirTurnoAtual();
    _atualizarPerdidas();
    final turno = _turnoAtual;
    final idx = _proximaIndex;
    final proxima = idx >= 0 ? turno.rondas[idx] : null;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Minhas Rondas'),
        actions: [
          IconButton(tooltip: 'Compartilhar histórico', icon: const Icon(Icons.share), onPressed: _compartilhar),
          IconButton(tooltip: 'Configurar', icon: const Icon(Icons.settings), onPressed: _configurar),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () async { _atualizarPerdidas(); setState(() {}); await _salvar(); },
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(children: [
                  const Text('PRÓXIMA RONDA', style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Text(proxima?.previsto ?? 'Aguardando horário', style: const TextStyle(fontSize: 42, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  Text(proxima == null ? 'Nenhuma ronda dentro da janela de registro' : 'Janela de registro: 30 minutos', style: const TextStyle(fontSize: 16)),
                  const SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    height: 58,
                    child: FilledButton.icon(
                      onPressed: proxima == null || _processando ? null : _registrar,
                      icon: _processando ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Icon(Icons.check_circle_outline),
                      label: const Text('REGISTRAR PASSAGEM', style: TextStyle(fontSize: 17)),
                    ),
                  ),
                ]),
              ),
            ),
            const SizedBox(height: 12),
            Text('Histórico de ${_formatarData(turno.dataInicio)}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            ...turno.rondas.map(_rondaTile),
            const SizedBox(height: 12),
            const Text('Histórico de dias anteriores', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            ..._turnos.where((t) => t.dataInicio != turno.dataInicio).map((t) => Card(
              child: ExpansionTile(
                title: Text('Turno de ${_formatarData(t.dataInicio)}'),
                subtitle: Text('${t.rondas.where((r) => r.status == 'concluida').length} concluídas • ${t.rondas.where((r) => r.status == 'perdida').length} perdidas'),
                children: t.rondas.map(_rondaTile).toList(),
              ),
            )),
            const SizedBox(height: 12),
            const Text('O registro só pode ser feito a partir do horário previsto e durante os 30 minutos seguintes. Os dados ficam salvos no aparelho.', style: TextStyle(color: Colors.grey), textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }
}
